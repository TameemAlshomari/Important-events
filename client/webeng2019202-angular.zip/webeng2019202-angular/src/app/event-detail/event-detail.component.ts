import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EventService } from '../event.service';
import { Event } from '../event';
import { Location } from '@angular/common';

@Component({
  selector: 'app-event-detail',
  templateUrl: './event-detail.component.html',
  styleUrls: ['./event-detail.component.css']
})
export class EventDetailComponent implements OnInit {

  event: Event = new Event();

  constructor(
    private route: ActivatedRoute,
    private eventService: EventService,
    // private location: Location
  ) { }

  async ngOnInit() {
    const id = +this.route.snapshot.paramMap.get('id');
    this.event = await this.eventService.getEvent(id);
  }

  // async onDelete() {
  //   await this.eventService.deleteEvent(this.event.id);
  //   this.location.back();
  // }

}

import { Injectable } from '@angular/core';
import { Issue } from './issue';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
    // Authorization: 'Basic dXNlcjpwYXNzd29yZA==',
  })
};

@Injectable({
  providedIn: 'root'
})
export class IssueService {

  private issueUrl = '/api/issues';

  constructor(
    private http: HttpClient
  ) { }

  getIssues() {
    // return this.issues;
    return this.http.get<Issue[]>(`${this.issueUrl}`, httpOptions).toPromise();
  }

  getIssue(id: number) {
    // return this.issues.find(issue => issue.id === id);
    return this.http.get<Issue>(`${this.issueUrl}/${id}`, httpOptions).toPromise();
  }

  modifyIssue(id: number, data) {
    // const issue = this.issues.find(iss => iss.id === id);
    // if (issue) {
    //   Object.assign(issue, data);
    // }
    // return issue;
    return this.http.put<Issue>(`${this.issueUrl}/${id}`, data, httpOptions).toPromise();
  }

  addIssue(data) {
    // const newIssue = Object.assign(new Issue(), data);
    // newIssue.id = this.issues.length + 1;
    // this.issues.push(newIssue);
    // return newIssue;
    return this.http.post<Issue>(`${this.issueUrl}`, data, httpOptions).toPromise();
  }

  deleteIssue(id: number) {
    // this.issues = this.issues.filter(iss => iss.id !== id);
    return this.http.delete<Issue>(`${this.issueUrl}/${id}`, httpOptions).toPromise();
  }
}

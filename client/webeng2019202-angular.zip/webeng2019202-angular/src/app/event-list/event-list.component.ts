import { Component, OnInit } from '@angular/core';
import { Event } from '../event';
import { EventService } from '../event.service';

@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.css']
})
export class EventListComponent implements OnInit {

  events: Event[] = [];
  status = 'ALL';
  // filteredIssues: Issue[] = this.issues;
  filteredEvents: Event[] = [];
  selectedEvent: Event = null;

  constructor(
    private eventService: EventService
  ) { }

  async ngOnInit() {
    // this.filteredIssues = this.issues;

    // this.filteredIssues = this.status === 'ALL'
    //   ? this.issues
    //   : this.issues.filter(issue => issue.status === this.status);

    this.events = await this.eventService.getEvents();
    
    this.filterEvents();
  }

  filterEvents() {
    // this.filterEvents = this.status === 'ALL'
    //   ? this.events
    //   : this.events.filter(event => event.status === this.status);
  }

  handleStatusChange(status) {
    this.status = status;
    this.filterEvents();
  }

  handleSave(event) {
    Object.assign(this.selectedEvent, event);
    this.selectedEvent = null;
  }

}

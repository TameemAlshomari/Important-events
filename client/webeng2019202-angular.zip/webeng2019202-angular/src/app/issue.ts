export class Issue {
  id: number;
  title = '';
  description = '';
  place = '';
  status = 'NEW';
}

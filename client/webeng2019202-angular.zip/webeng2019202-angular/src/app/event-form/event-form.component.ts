import { Component, OnInit, OnChanges, Input, Output, EventEmitter } from '@angular/core';
import {  Event } from '../event';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-event-form',
  templateUrl: './event-form.component.html',
  styleUrls: ['./event-form.component.css']
})
export class EventFormComponent implements OnInit, OnChanges {

  @Input() event: Event;
  @Output() save = new EventEmitter<Event>();

  eventForm = this.fb.group({
    title: ['', [Validators.required]],
    note: ['', [Validators.required]],
    location: ['', [Validators.required]],
    updated_at: ['', [Validators.required]],
  });
  get title() { return this.eventForm.get('title'); }
  get note() { return this.eventForm.get('note'); }
  get location() { return this.eventForm.get('location'); }
  get updated_at() { return this.eventForm.get('updated_at'); }

  constructor(
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {
    // this.issueForm.get('title').setValue(this.issue.title);
  }

  ngOnChanges() {
    this.eventForm.markAsUntouched();
    this.eventForm.patchValue(this.event);
  }

  onSubmit() {
 
    if (this.eventForm.valid) {
  
      this.save.emit(this.eventForm.value);
    }
  }

}

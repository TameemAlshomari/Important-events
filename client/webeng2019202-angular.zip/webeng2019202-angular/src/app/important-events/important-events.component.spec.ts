
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportantEventsComponent } from './important-events.component';

describe('ImportantEventsComponent', () => {
  let component: ImportantEventsComponent;
  let fixture: ComponentFixture<ImportantEventsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportantEventsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportantEventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

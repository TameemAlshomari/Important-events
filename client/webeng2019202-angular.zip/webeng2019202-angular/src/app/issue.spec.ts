import { Issue } from './issue';

describe('Issue', () => {
  it('should create an instance', () => {
    expect(new Issue()).toBeTruthy();
  });
});

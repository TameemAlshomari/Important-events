import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { User } from './user';

const httpOptions = token => ({
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
    // Authorization: `Basic ${token}`,
  })
});

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  isLoggedIn = false;
  redirectUrl = '';
  user: User = null;
  token = '';
  authUrl = '/api/auth';

  constructor(
    private http: HttpClient
  ) { }

  async login(username: string, password: string): Promise<User> {
    try {
      this.token = btoa(`${username}:${password}`);
      const user = await this.http.post<User>(`${this.authUrl}/login`, {}, httpOptions(this.token)).toPromise();
      this.isLoggedIn = true;
      this.user = user;
      return this.user;
    } catch (e) {
      console.log(e);
      return Promise.reject();
    }
  }

  logout() {
    this.token = '';
    this.isLoggedIn = false;
    this.user = null;
  }
}

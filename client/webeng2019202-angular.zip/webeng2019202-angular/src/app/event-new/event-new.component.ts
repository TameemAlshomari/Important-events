
import { Component, OnInit, OnChanges, Input, Output, EventEmitter } from '@angular/core';
import {  Event } from '../event';
import { FormBuilder, Validators } from '@angular/forms';
import { EventService } from '../event.service';
import { ActivatedRoute, Router } from '@angular/router';

import { Location } from '@angular/common';

@Component({
  selector: 'app-event-new',
  templateUrl: './event-new.component.html',
  styleUrls: ['./event-new.component.css']
})
export class EventNewComponent implements OnInit, OnChanges {

  @Input() event: Event;
  @Output() save = new EventEmitter<Event>();

  eventForm = this.fb.group({
    title: ['', [Validators.required]],
    note: ['', [Validators.required]],
    location: ['', [Validators.required]],
    updated_at: ['', [Validators.required]],
  });
  get title() { return this.eventForm.get('title'); }
  get note() { return this.eventForm.get('note'); }
  get location() { return this.eventForm.get('location'); }
  get updated_at() { return this.eventForm.get('updated_at'); }

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private eventService: EventService,
    // private location: Location,
    private router: Router
  ) { }





  ngOnInit(): void {
    // this.issueForm.get('title').setValue(this.issue.title);
  }

  ngOnChanges() {
    this.eventForm.markAsUntouched();
    this.eventForm.patchValue(this.event);
  }

  async onSubmit() {
 
    if (this.eventForm.valid) {
  
      // this.save.emit(this.eventForm.value);
      await this.eventService.addEvent(this.eventForm.value);
      this.router.navigate(['events']);
    }
  }
  // async handleSave(formData: Event) {
    
  //   if (this.id) {
  //     await this.eventService.modifyEvent(this.id, formData);
  //     this.router.navigate(['events']);
  //   } else {
  //     await this.eventService.addEvent(formData);
  //     this.router.navigate(['events']);
  //   }
  // }

}


import { Component, OnInit } from '@angular/core';
import { EventService } from '../event.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Event } from '../event';
import { Location } from '@angular/common';

@Component({
  selector: 'app-event-edit',
  templateUrl: './event-edit.component.html',
  styleUrls: ['./event-edit.component.css']
})
export class EventEditComponent implements OnInit {

  event: Event = new Event();
  id: number = null;

  constructor(
    private route: ActivatedRoute,
    private eventService: EventService,
    private location: Location,
    private router: Router
  ) { }

  async ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.id = +id;
      this.event = await this.eventService.getEvent(this.id);
    }
  }

  async handleSave(formData: Event) {
    
    if (this.id) {
      await this.eventService.modifyEvent(this.id, formData);
      this.router.navigate(['events']);
    } else {
      await this.eventService.addEvent(formData);
      this.router.navigate(['events']);
    }
  }
}

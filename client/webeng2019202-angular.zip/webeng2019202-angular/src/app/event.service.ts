import { Injectable } from '@angular/core';
import { Event } from './event';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
    // Authorization: 'Basic dXNlcjpwYXNzd29yZA==',
  })
};

@Injectable({
  providedIn: 'root'
})
export class EventService {

  private eventUrl = '/api/events';

  constructor(
    private http: HttpClient
  ) { }

  getEvents() {
    // return this.issues;
    return this.http.get<Event[]>(`${this.eventUrl}`, httpOptions).toPromise();
  }

  getEvent(id: number) {
    // return this.issues.find(issue => issue.id === id);
    return this.http.get<Event>(`${this.eventUrl}/${id}`, httpOptions).toPromise();
  }

  modifyEvent(id: number, data) {
    // const issue = this.issues.find(iss => iss.id === id);
    // if (issue) {
    //   Object.assign(issue, data);
    // }
    // return issue;
    return this.http.put<Event>(`${this.eventUrl}/${id}`, data, httpOptions).toPromise();
  }

  addEvent(data) {
 
    // const newIssue = Object.assign(new Issue(), data);
    // newIssue.id = this.issues.length + 1;
    // this.issues.push(newIssue);
    // return newIssue;
    return this.http.post<Event>(`${this.eventUrl}`, data, httpOptions).toPromise();
  }

  deleteEvent(id: number) {
    // this.issues = this.issues.filter(iss => iss.id !== id);
    return this.http.delete<Event>(`${this.eventUrl}/${id}`, httpOptions).toPromise();
  }
}

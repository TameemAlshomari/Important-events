export class Event {
    id: number;
    title = '';
    note = '';
    location = '';
    updated_at = '';
}

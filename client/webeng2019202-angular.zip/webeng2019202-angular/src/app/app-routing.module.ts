import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainPageComponent } from './main-page/main-page.component';
import { IssueListComponent } from './issue-list/issue-list.component';
import { IssueDetailComponent } from './issue-detail/issue-detail.component';
import { IssueEditComponent } from './issue-edit/issue-edit.component';
import { AuthGuard } from './auth.guard';
import { LoginComponent } from './login/login.component';
import { EventNewComponent } from './event-new/event-new.component';
import { EventListComponent } from './event-list/event-list.component';
import { EventDetailComponent } from './event-detail/event-detail.component';
import { EventEditComponent } from './event-edit/event-edit.component';
import {AboutComponent} from './about/about.component';


const routes: Routes = [
  {
    path: '',
    component: MainPageComponent
  },
  {
    path: 'about',
    component: AboutComponent,
    // canActivate: [AuthGuard],
  },
  {
    path: 'events',
    component: EventListComponent,
    // canActivate: [AuthGuard],
  },
  {
    path: 'events/new',
    component: EventNewComponent,
  },
  {
    path: 'events/:id',
    component: EventDetailComponent,
    // canActivate: [AuthGuard],
  },
  {
    path: 'events/:id/edit',
    component: EventEditComponent,
    // canActivate: [AuthGuard],
  },
  {
    path: 'issues',
    component: IssueListComponent,
    // canActivate: [AuthGuard],
  },
//   {
//     path: 'issues/new',
//     component: IssueEditComponent,
//  // canActivate: [AuthGuard],
//   },
//   {
//     path: 'issues/:id',
//     component: IssueDetailComponent,
//     canActivate: [AuthGuard],
//   },
//   {
//     path: 'issues/:id/edit',
//     component: IssueEditComponent,
//     canActivate: [AuthGuard],
//   },
//   {
//     path: 'login',
//     component: LoginComponent,
//   },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
